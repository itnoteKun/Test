package com.cityWeather.temp;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.db.DBConfiguration;
import org.apache.hadoop.mapreduce.lib.db.DBInputFormat;
import org.apache.hadoop.mapreduce.lib.db.DBOutputFormat;

import java.io.IOException;

public class tempDriver {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {

        //获取job
        Job job = Job.getInstance(new Configuration());

        //设置jar路径
        job.setJarByClass(tempDriver.class);

        //设置数据输入类型为数据库输入
        job.setInputFormatClass(DBInputFormat.class);

        //设置数据库配置并连接
        String driverClass = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://192.168.10.101:3306/dbAnalysis";
        String usr = "root";
        String pwd = "120710";

        DBConfiguration.configureDB(job.getConfiguration(), driverClass, url, usr, pwd);

        //设置数据输入内容
        DBInputFormat.setInput(job, tempSeqBean.class,
                "select * from cityWeather",
                "select count(*) from cityWeather");

        //设置输出的表
        DBOutputFormat.setOutput(job, "cityMaxAndMin", "city", "tempMax", "tempMin");

        //关联mapper与reducer
        job.setMapperClass(tempMapper.class);
        job.setReducerClass(tempReducer.class);

        //设置map阶段输出的kv类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        //设置最终输出的kv类型
        job.setOutputKeyClass(tempSeqBean.class);
        job.setOutputValueClass(NullWritable.class);

        //提交job
        boolean b = job.waitForCompletion(true);
        System.exit(b ? 0 : 1);
    }
}
